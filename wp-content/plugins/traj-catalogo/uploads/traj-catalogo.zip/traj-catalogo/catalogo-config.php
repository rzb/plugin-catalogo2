<?php

// configurações
define("TRAJ_PALAVRAS_TABLE", "traj_palavras");
define("TRAJ_TRABALHOS_TABLE", "traj_trabalhos");

?>